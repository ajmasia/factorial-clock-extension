console.log("[Factorial API Content Script] Loaded on",window.location.href);chrome.runtime.onMessage.addListener((t,r,o)=>{if(console.log("[Factorial API] Received message:",t.action,t),t.action==="ping"){o({success:!0,data:"pong"});return}if(t.action==="getEmployeeId")return y().then(e=>{console.log("[Factorial API] Employee ID:",e),o({success:!0,data:e})}).catch(e=>{console.error("[Factorial API] Error getting employee ID:",e),o({success:!1,error:e.message})}),!0;if(t.action==="createShift")return console.log("[Factorial API] Creating shift:",t.data),I(t.data).then(e=>{console.log("[Factorial API] Shift created:",e),o({success:!0,data:e})}).catch(e=>{e.message.includes("overlaps with shift")||console.error("[Factorial API] Error creating shift:",e),o({success:!1,error:e.message})}),!0});async function y(){console.log("[Factorial API] Getting employee credentials...");const t=await fetch("https://app.factorialhr.com/resources/api_public/credentials",{method:"GET",credentials:"include",headers:{Accept:"application/json","X-Requested-With":"XMLHttpRequest"}});if(console.log("[Factorial API] Response status:",t.status),!t.ok)throw new Error(`Failed to get credentials: HTTP ${t.status}`);const r=await t.json();if(console.log("[Factorial API] Credentials response:",r),!r.data||!Array.isArray(r.data)||r.data.length===0)throw new Error("Invalid credentials response format");const o=r.data[0];if(!o.employee_id)throw new Error("Employee ID not found in credentials");return console.log("[Factorial API] ✓ Employee ID found:",o.employee_id),o.employee_id}async function I({employeeId:t,clockIn:r,clockOut:o,date:e}){var d,p,h,u,f,g,m;console.log("[Factorial API] Creating shift:",{employeeId:t,clockIn:r,clockOut:o,date:e});const a=await fetch("https://api.factorialhr.com/graphql?CreateAttendanceShift",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json",Accept:"application/json","X-Requested-With":"XMLHttpRequest"},body:JSON.stringify({operationName:"CreateAttendanceShift",variables:{date:e,employeeId:t,clockIn:r,clockOut:o,referenceDate:e,source:"desktop",workable:!0},query:`
mutation CreateAttendanceShift($clockIn: ISO8601DateTime, $clockOut: ISO8601DateTime, $date: ISO8601Date!, $employeeId: Int!, $halfDay: String, $locationType: AttendanceShiftLocationTypeEnum, $observations: String, $referenceDate: ISO8601Date!, $source: AttendanceEnumsShiftSourceEnum, $timeSettingsBreakConfigurationId: Int, $workable: Boolean) {
  attendanceMutations {
    createAttendanceShift(
      clockIn: $clockIn
      clockOut: $clockOut
      date: $date
      employeeId: $employeeId
      halfDay: $halfDay
      locationType: $locationType
      observations: $observations
      referenceDate: $referenceDate
      source: $source
      timeSettingsBreakConfigurationId: $timeSettingsBreakConfigurationId
      workable: $workable
    ) {
      errors {
        ... on SimpleError {
          message
          type
          __typename
        }
        ... on StructuredError {
          field
          messages
          __typename
        }
        __typename
      }
      shift {
        id
        clockIn
        clockOut
        date
        __typename
      }
      __typename
    }
    __typename
  }
}
`})});if(console.log("[Factorial API] Response status:",a.status,a.statusText),console.log("[Factorial API] Response headers:",{contentType:a.headers.get("Content-Type"),contentLength:a.headers.get("Content-Length")}),!a.ok){const s=await a.text();throw console.error("[Factorial API] Error response body:",s.substring(0,500)),a.status===401?new Error("Not authenticated. Please log in to Factorial in your browser first."):new Error(`HTTP ${a.status}: ${a.statusText}`)}const i=a.headers.get("Content-Type");if(!i||!i.includes("application/json")){const s=await a.text();throw console.error("[Factorial API] Non-JSON response:",s.substring(0,500)),new Error(`Expected JSON but got ${i}. Response: ${s.substring(0,100)}`)}const n=await a.json();console.log("[Factorial API] Response:",n);const c=((h=(p=(d=n==null?void 0:n.data)==null?void 0:d.attendanceMutations)==null?void 0:p.createAttendanceShift)==null?void 0:h.errors)||[];if(c.length>0){const s=((u=c[0].messages)==null?void 0:u[0])||c[0].message||"Unknown error";throw s.includes("overlaps with shift")||console.error("[Factorial API] GraphQL errors:",c),new Error(s)}const l=(m=(g=(f=n==null?void 0:n.data)==null?void 0:f.attendanceMutations)==null?void 0:g.createAttendanceShift)==null?void 0:m.shift;if(!l)throw console.error("[Factorial API] No shift in response:",n),new Error("Shift creation failed: No shift returned");return console.log("[Factorial API] Shift created:",l.id),l}
